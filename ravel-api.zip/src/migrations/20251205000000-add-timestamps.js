'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    const { DATE } = Sequelize;

    // USERS – already has createdAt, so only add updatedAt
    await queryInterface.addColumn('users', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });

    // HOTELS
    await queryInterface.addColumn('hotels', 'createdAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
    await queryInterface.addColumn('hotels', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });

    // ATTRACTIONS
    await queryInterface.addColumn('attractions', 'createdAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
    await queryInterface.addColumn('attractions', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });

    // TOURS
    await queryInterface.addColumn('tours', 'createdAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
    await queryInterface.addColumn('tours', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });

    // BOOKINGS
    await queryInterface.addColumn('bookings', 'createdAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
    await queryInterface.addColumn('bookings', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });

    // REVIEWS
    await queryInterface.addColumn('reviews', 'createdAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
    await queryInterface.addColumn('reviews', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });

    // FAVORITES
    await queryInterface.addColumn('favorites', 'createdAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
    await queryInterface.addColumn('favorites', 'updatedAt', {
      type: DATE,
      allowNull: false,
      defaultValue: Sequelize.fn('NOW')
    });
  },

  async down(queryInterface) {
    // Reverse operations
    await queryInterface.removeColumn('users', 'updatedAt');

    await queryInterface.removeColumn('hotels', 'createdAt');
    await queryInterface.removeColumn('hotels', 'updatedAt');

    await queryInterface.removeColumn('attractions', 'createdAt');
    await queryInterface.removeColumn('attractions', 'updatedAt');

    await queryInterface.removeColumn('tours', 'createdAt');
    await queryInterface.removeColumn('tours', 'updatedAt');

    await queryInterface.removeColumn('bookings', 'createdAt');
    await queryInterface.removeColumn('bookings', 'updatedAt');

    await queryInterface.removeColumn('reviews', 'createdAt');
    await queryInterface.removeColumn('reviews', 'updatedAt');

    await queryInterface.removeColumn('favorites', 'createdAt');
    await queryInterface.removeColumn('favorites', 'updatedAt');
  }
};
